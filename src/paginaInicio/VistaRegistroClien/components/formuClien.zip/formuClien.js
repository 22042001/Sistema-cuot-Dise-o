import React from 'react';

const FormuClien = () => {
    const [formData, setFormData] = React.useState({
        Nombre: '',
        Apellidos: '',
        Contrasena: '',
        Email: '',
        Telefono: '',
        Direccion: '',
        Genero: ''
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(formData);
    };

    return (
        <div className="p-8 bg-white flex flex-col justify-center min-h-screen">
            <div className="w-full max-w-screen-lg mx-auto">
                <h1 className="text-4xl font-bold text-gray-700">Registro de Cliente</h1>
                <form onSubmit={handleSubmit} className="mt-8 grid grid-cols-2 gap-6">
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Nombre</label>
                        <input
                            type="text"
                            name="Nombre"
                            value={formData.Nombre}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Apellidos</label>
                        <input
                            type="text"
                            name="Apellidos"
                            value={formData.Apellidos}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Contrasena</label>
                        <input
                            type="password"
                            name="Contrasena"
                            value={formData.Contrasena}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Email</label>
                        <input
                            type="email"
                            name="Email"
                            value={formData.Email}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Telefono</label>
                        <input
                            type="text"
                            name="Telefono"
                            value={formData.Telefono}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Direccion</label>
                        <input
                            type="text"
                            name="Direccion"
                            value={formData.Direccion}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        />
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 capitalize">Genero</label>
                        <select
                            name="Genero"
                            value={formData.Genero}
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded"
                            required
                        >
                            <option value="">Selecciona</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Femenino">Femenino</option>
                        </select>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default FormuClien;
